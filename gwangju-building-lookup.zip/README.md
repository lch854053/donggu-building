# 광주광역시 동구 건축물대장 일괄조회

주소 목록을 붙여넣으면 **표제부 + 기본개요**를 한 번에 조회하는 도구입니다.
지번·도로명 주소를 섞어 입력할 수 있고, 광주 동구(`29110`) 외 주소는 자동 제외됩니다.

## 구조

```
주소 입력
  → /api/juso      행안부 도로명주소 검색 → 지번 정보(admCd, 본번/부번, 산여부)
  → 변환            admCd→시군구·법정동, 본번→bun, 부번→ji
  → /api/building   건축HUB 표제부 + 기본개요 (서버 측 호출, CORS 없음)
  → 화면 표 + 엑셀
```

- `index.html` — 프론트엔드 (조회 로직·테이블·엑셀)
- `api/juso.js` — 도로명주소 검색 프록시
- `api/building.js` — 건축HUB 표제부+기본개요 프록시

> 두 외부 API 모두 브라우저 직접 호출 시 CORS로 막히므로, Vercel 서버리스 함수가 대신 호출합니다.
> API 키는 코드가 아니라 환경변수에만 보관됩니다.

## 배포 (Vercel)

1. 이 폴더를 GitHub 저장소에 올립니다.
2. vercel.com → New Project → 저장소 import.
3. **Settings → Environment Variables** 에 두 개 등록:
   - `JUSO_CONFM_KEY` : 도로명주소 **검색 API** 승인키 (팝업용 승인키는 불가)
   - `BLD_SERVICE_KEY` : 건축HUB **디코딩(Decoding) 키**
4. Deploy. 끝나면 발급된 주소를 직원들에게 공유.

환경변수를 바꾼 뒤에는 **Redeploy** 해야 반영됩니다.

## 로컬 테스트

```bash
npm i -g vercel       # 최초 1회
vercel dev            # http://localhost:3000
```

`vercel dev` 가 `.env.local` 을 읽습니다. `.env.example` 을 복사해서 만드세요:

```bash
cp .env.example .env.local   # 값 채우기
```

## 키 발급처

| 키 | 발급처 |
|---|---|
| `JUSO_CONFM_KEY` | juso.go.kr → 개발자센터 → 검색 API |
| `BLD_SERVICE_KEY` | data.go.kr → 건축HUB_건축물대장정보 서비스 (표제부·기본개요 활용신청) |

## 자주 막히는 곳

- **건축HUB 인증오류(SERVICE KEY ... ERROR)**: Encoding 키를 넣으면 발생. **Decoding 키**로 교체.
- **juso E0001**: 팝업 API 승인키를 넣은 경우. **검색 API** 승인키로 교체.
- **조회는 되는데 0건**: 해당 지번에 건축물대장이 없거나(나대지 등), 번/지 자리수 문제. 입력 주소를 확인.
- **다른 구 조회 필요 시**: `index.html` 의 `isDonggu()` 와 시군구코드 필터만 수정하면 확장 가능.
